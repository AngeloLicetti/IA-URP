// 
// Decompiled by Procyon v0.5.36
// 

package Rule;

public interface Sensor
{
    Boolean sensor(final Object p0, final String p1, final RuleVariable p2);
}
