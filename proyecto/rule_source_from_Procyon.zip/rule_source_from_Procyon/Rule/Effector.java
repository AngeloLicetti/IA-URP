// 
// Decompiled by Procyon v0.5.36
// 

package Rule;

public interface Effector
{
    long effector(final Object p0, final String p1, final String p2);
}
